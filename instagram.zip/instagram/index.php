<?php
session_start();
if(!isset ($_SESSION['login'])) {
    header("location:login.php?pesan=login dulu");
}

include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no desc";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="index.css">
    <link rel="icon" href="./images/logosheva.png">
    <title>SepGram</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-secondary sticky-top" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <img src="./images/logosheva.png" alt="" width="50" height="60">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarColor02">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                <a class="nav-link active" href="#">
                    <span class="visually-hidden">(current)</span>
                </a>
                </li>
            </ul>
            <form class="d-flex">
                <a class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="bi bi-file-plus"></i></a>
                <a class="btn btn-danger" href="logout.php">Logout</a>
            </form>
            </div>
        </div>
        </nav>

    <!-- <h2 class="text-center mt-3">Beranda</h2><br> -->


        <?php while($post = mysqli_fetch_assoc($query)) { ?>
            <div class="card mx-auto mt-4" style="width: 18rem;">
            <div class="img-area">
                <img src="images/<?= $post['gambar'] ?>" class="card-img-top" alt="404" width="100">
            </div>
                <div class="card-body">
                    <h5 class="card-text"><?= $post['caption']?></h5>
                    <p class="card-text"><?= $post['lokasi'] ?></p>
                    <a href="hapus.php?no=<?= $post['no'] ?>" class="btn btn-danger"><i class="bi bi-trash3-fill"></i></a>
                    <a href="edit.php?no=<?= $post['no'] ?>" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $post['no'] ?>"><i class="bi bi-pen-fill"></i></a>
                </div>
                </div>
        
        </div>

    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Tambah</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form action="proses-tambah.php" method="post" enctype="multipart/form-data">

            <div class="form-group">
                <label class="form-label mt-4" for="">Foto</label>
                <input class="form-control" type="file" name="gambar" id="" required>
            </div><br>

            <div class="form-group">
                <label class="form-label mt-4" for="">Caption</label>
                <input class="form-control" type="text" name="caption" id="" autocomplete="off">
            </div><br>

            <div class="form-group">
                <label class="form-label mt-4" for="">Lokasi</label>
                <input class="form-control" type="text" name="lokasi" id="" autocomplete="off">
            </div><br>

            <input class="btn btn-success" type="submit" value="Simpan" name="simpan">
            </form>
            </div>
    
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalEdit<?= $post['no'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form action="proses-edit.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="no" value="<?= $post['no'] ?>">
                <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
                
                <div class="form-group">
                        <label class="form-label mt-4" for="">Foto</label>
                        <input class="form-control" type="file" name="gambar" id="" required><br>
                        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>
                    </div><br>

                    <div class="form-group">
                        <label class="form-label mt-4" for="">Caption</label>
                        <input class="form-control" type="text" name="caption" value="<?= $post['caption'] ?>" id="" autocomplete="off">
                    </div><br>

                    <div class="form-group">
                        <label class="form-label mt-4" for="">Lokasi</label>
                        <input class="form-control" type="text" name="lokasi" value="<?= $post['lokasi'] ?>" id="" autocomplete="off">
                    </div><br>

                <input class="btn btn-success" type="submit" value="Update" name="update">
            </form>
            </div>
            
            </div>
        </div>
    </div>
    <?php } ?>
</body>
</html>
