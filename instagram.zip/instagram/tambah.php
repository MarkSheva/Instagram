<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container"> 
        <h1 class="text-center">Tambah Postingan</h1>
        <a class="btn btn-dark" href="index.php">Kembali</a>
        <form action="proses-tambah.php" method="post" enctype="multipart/form-data">

            <div class="form-group">
                <label class="form-label mt-4" for="">Foto</label>
                <input class="form-control" type="file" name="gambar" id="" required>
            </div><br>

            <div class="form-group">
                <label class="form-label mt-4" for="">Caption</label>
                <input class="form-control" type="text" name="caption" id="" autocomplete="off">
            </div><br>

            <div class="form-group">
                <label class="form-label mt-4" for="">Lokasi</label>
                <input class="form-control" type="text" name="lokasi" id="" autocomplete="off">
            </div><br>

            <input class="btn btn-success" type="submit" value="Simpan" name="simpan">
    </form>
    </div>
</body>
</html>