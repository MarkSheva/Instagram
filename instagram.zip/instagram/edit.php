<?php
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
    <h1 class="text-center">Edit Postingan</h1>
    <a class="btn btn-dark" href="index.php">Kembali</a>
    <form action="proses-edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
        
        <div class="form-group">
                <label class="form-label mt-4" for="">Foto</label>
                <input class="form-control" type="file" name="gambar" id="" required><br>
                <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>
            </div><br>

            <div class="form-group">
                <label class="form-label mt-4" for="">Caption</label>
                <input class="form-control" type="text" name="caption" value="<?= $post['caption'] ?>" id="" autocomplete="off">
            </div><br>

            <div class="form-group">
                <label class="form-label mt-4" for="">Lokasi</label>
                <input class="form-control" type="text" name="lokasi" value="<?= $post['lokasi'] ?>" id="" autocomplete="off">
            </div><br>

        <input class="btn btn-success" type="submit" value="Update" name="update">
    </form>
    </div>
</body>
</html>

<?php } ?>