<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="./images/logosheva.png">
    <title>Login</title>
</head>
<body>
        <form action="proses-login.php" method="post">
                
        <div align="center">
            <img src="./images/logosheva.png" alt="Bootstrap" width="60" height="60">
        </div>
            
        <label for="username">Username</label>
        <input type="text" name="username" id="username" autocomplete="">

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <button class="btn">Login</button>
    </form>
</body>
</html>